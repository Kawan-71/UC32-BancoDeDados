CREATE TABLE `livros` (
  `id_livro` integer PRIMARY KEY AUTO_INCREMENT,
  `titulo` varchar(150) NOT NULL,
  `ano_publicacao` integer,
  `genero` varchar(50),
  `quantidade` integer NOT NULL
);

CREATE TABLE `autores` (
  `id_autor` integer PRIMARY KEY AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `nacionalidade` varchar(50)
);

CREATE TABLE `leitores` (
  `id_leitor` integer PRIMARY KEY AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `email` varchar(100) UNIQUE,
  `telefone` varchar(20)
);

CREATE TABLE `emprestimos` (
  `id_emprestimo` integer PRIMARY KEY AUTO_INCREMENT,
  `id_livro` integer NOT NULL,
  `id_leitor` integer NOT NULL,
  `data_emprestimo` date NOT NULL,
  `data_devolucao` date
);

CREATE TABLE `livro_autor` (
  `id_livro` integer NOT NULL,
  `id_autor` integer NOT NULL,
  PRIMARY KEY (`id_livro`, `id_autor`)
);

ALTER TABLE `emprestimos` ADD FOREIGN KEY (`id_livro`) REFERENCES `livros` (`id_livro`);

ALTER TABLE `emprestimos` ADD FOREIGN KEY (`id_leitor`) REFERENCES `leitores` (`id_leitor`);

ALTER TABLE `livro_autor` ADD FOREIGN KEY (`id_livro`) REFERENCES `livros` (`id_livro`);

ALTER TABLE `livro_autor` ADD FOREIGN KEY (`id_autor`) REFERENCES `autores` (`id_autor`);
